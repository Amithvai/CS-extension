package com.phisher98

import android.content.SharedPreferences
import android.util.Base64
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.cloudstream3.CommonActivity.activity
import com.lagradost.cloudstream3.DubStatus
import com.lagradost.cloudstream3.Episode
import com.lagradost.cloudstream3.ErrorLoadingException
import com.lagradost.cloudstream3.HomePageList
import com.lagradost.cloudstream3.HomePageResponse
import com.lagradost.cloudstream3.LoadResponse
import com.lagradost.cloudstream3.LoadResponse.Companion.addAniListId
import com.lagradost.cloudstream3.LoadResponse.Companion.addMalId
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.MainPageRequest
import com.lagradost.cloudstream3.mvvm.logError
import com.lagradost.cloudstream3.Score
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.ShowStatus
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.addDate
import com.lagradost.cloudstream3.addEpisodes
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.mainPageOf
import com.lagradost.cloudstream3.newAnimeLoadResponse
import com.lagradost.cloudstream3.newAnimeSearchResponse
import com.lagradost.cloudstream3.newEpisode
import com.lagradost.cloudstream3.newHomePageResponse
import com.lagradost.cloudstream3.newMovieLoadResponse
import com.lagradost.cloudstream3.runAllAsync
import com.lagradost.cloudstream3.syncproviders.AccountManager
import com.lagradost.cloudstream3.syncproviders.SyncIdName
import com.lagradost.cloudstream3.syncproviders.SyncRepo
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.CoverImage
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.LikePageInfo
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.RecommendationConnection
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.SeasonNextAiringEpisode
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.Title
import com.lagradost.cloudstream3.utils.AppUtils
import com.lagradost.cloudstream3.utils.AppUtils.toJson
import com.lagradost.cloudstream3.utils.AppUtils.tryParseJson
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.nicehttp.RequestBodyTypes
import com.phisher98.TorraStream.Companion.Meteorfortheweebs
import com.phisher98.TorraStream.Companion.TorboxAPI
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.Calendar

open class TorraStreamAnime(private val sharedPref: SharedPreferences) : MainAPI() {
    override var name = "TorraStream-Anime"
    override var mainUrl = "https://anilist.co"
    override var supportedTypes = setOf(TvType.Anime, TvType.AnimeMovie, TvType.OVA)
    override var lang = "en"
    override val supportedSyncNames = setOf(SyncIdName.Anilist)
    override val hasMainPage = true
    override val hasQuickSearch = false
    private val repo = SyncRepo(AccountManager.aniListApi)
    private val apiUrl = "https://graphql.anilist.co"
    private val anilistAPI = "https://graphql.anilist.co"
    private val mediaLimit = 20
    private val isAdult = false
    private val headerJSON =
        mapOf("Accept" to "application/json", "Content-Type" to "application/json")
    private val torrentioDebian= "https://torrentio.strem.fun"
    private val TorrentsDB = "https://torrentsdb.com"

    private fun Any.toStringData(): String {
        return this.toJson()
    }

    private suspend fun anilistAPICall(query: String): AnilistAPIResponse? {
        val data = mapOf("query" to query)
        val test = runCatching {
            app.post(apiUrl, headers = headerJSON, data = data, timeout = 15_000L)
        }.getOrNull() ?: return null
        return runCatching {
            test.text.let { tryParseJson<AnilistAPIResponse>(it) }
        }.getOrNull()
    }

    private fun Media.toSearchResponse(): SearchResponse {
        val title = this.title.english ?: this.title.romaji ?: ""
        val url = "$mainUrl/anime/${this.id}"
        val posterUrl = this.coverImage.large
        val rating = this.averageScore
        return newAnimeSearchResponse(title, url, TvType.Anime) {
            this.posterUrl = posterUrl
            this.score= Score.from100(rating)
        }
    }

    private suspend fun MainPageRequest.toSearchResponseList(
        page: Int
    ): Pair<List<SearchResponse>, Boolean> {
        val res = anilistAPICall(this.data.replace("###", "$page"))
        val data = res?.data?.page?.media?.map { it.toSearchResponse() }
            ?: return emptyList<SearchResponse>() to false
        val hasNextPage = res.data.page.pageInfo.hasNextPage ?: false
        return data to hasNextPage
    }
    private val currentYear = Calendar.getInstance().get(Calendar.YEAR)

    override val mainPage =
        mainPageOf(
            "query (\$page: Int = ###, \$sort: [MediaSort] = [TRENDING_DESC, POPULARITY_DESC], \$isAdult: Boolean = $isAdult) { Page(page: \$page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(sort: \$sort, isAdult: \$isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters averageScore title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }" to
                    "Trending Now",
            "query (\$page: Int = ###, \$seasonYear: Int = $currentYear, \$sort: [MediaSort] = [TRENDING_DESC, POPULARITY_DESC], \$isAdult: Boolean = $isAdult) { Page(page: \$page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(sort: \$sort, seasonYear: \$seasonYear, season: SPRING, isAdult: \$isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters averageScore title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }" to
                    "Popular This Season",
            "query (\$page: Int = ###, \$sort: [MediaSort] = [POPULARITY_DESC], \$isAdult: Boolean = $isAdult) { Page(page: \$page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(sort: \$sort, isAdult: \$isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters averageScore title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }" to
                    "All Time Popular",
            "query (\$page: Int = ###, \$sort: [MediaSort] = [SCORE_DESC], \$isAdult: Boolean = $isAdult) { Page(page: \$page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(sort: \$sort, isAdult: \$isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters averageScore title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }" to
                    "Top 100 Anime",
            "Personal" to "Personal"
        )

    override suspend fun search(query: String): List<SearchResponse>? {
        val res = anilistAPICall(
            "query (\$search: String = \"$query\") { Page(page: 1, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(search: \$search, isAdult: $isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }"
        )
        return res?.data?.page?.media?.map { it.toSearchResponse() }
    }

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        if (request.name.contains("Personal")) {
            repo.authUser()
                ?: return newHomePageResponse(
                    "Login required for personal content.",
                    emptyList<SearchResponse>(),
                    false
                )
            val homePageList =
                repo.library().getOrThrow()?.allLibraryLists.orEmpty().mapNotNull {
                    if (it.items.isEmpty()) return@mapNotNull null
                    val libraryName =
                        it.name.asString(activity ?: return@mapNotNull null)
                    HomePageList("${request.name}: $libraryName", it.items)
                }
            return newHomePageResponse(homePageList, false)
        } else {
            val data = request.toSearchResponseList(page)
            return newHomePageResponse(request.name, data.first, data.second)
        }
    }

    override suspend fun load(url: String): LoadResponse? {
        val id = url.removeSuffix("/").substringAfterLast("/")
        val data = runCatching {
            anilistAPICall(
                "query (\$id: Int = $id) { Media(id: \$id, type: ANIME) { id title { romaji english } startDate { year } genres description averageScore status bannerImage coverImage { extraLarge large medium } bannerImage episodes format nextAiringEpisode { episode } airingSchedule { nodes { episode } } recommendations { edges { node { id mediaRecommendation { id title { romaji english } coverImage { extraLarge large medium } } } } } } }"
            )?.data?.media
        }.getOrNull() ?: return null

        val anititle = data.getTitle()
        val aniyear = data.startDate.year
        val anitype = if (data.format?.contains("MOVIE", ignoreCase = true) == true) TvType.AnimeMovie else TvType.TvSeries
        val ids = tmdbToAnimeId(anititle, aniyear, anitype)
        val posterurl = data.coverImage.extraLarge
        val backgroundUrl = data.bannerImage

        val jpTitle = data.title.romaji
        val syncMetaData = runCatching {
            app.get("https://api.ani.zip/mappings?anilist_id=${ids.id}", timeout = 10_000L).text
        }.getOrNull().orEmpty()
        val animeMetaData = tryParseJson<MetaAnimeData>(syncMetaData)
        val logoposter = animeMetaData?.images?.find { it.coverType == "Clearlogo" }?.url

        val href = LinkData(
            malId = ids.idMal,
            aniId = ids.id,
            title = data.getTitle(),
            jpTitle = jpTitle,
            year = data.startDate.year,
            isAnime = true
        ).toStringData()

        fun resolveTitle(epData: MetaEpisode?): String {
            val jsonTitle = epData?.title?.get("en")
                ?: epData?.title?.get("ja")
                ?: epData?.title?.get("x-jat")
                ?: animeMetaData?.titles?.get("en")
                ?: animeMetaData?.titles?.get("ja")
                ?: animeMetaData?.titles?.get("x-jat")
                ?: ""
            return jsonTitle.ifBlank { "Episode ${epData?.episode ?: ""}" }
        }

        fun createEpisode(i: Int): Episode {
            val epData = animeMetaData?.episodes?.get(i.toString())
            val linkData = LinkData(
                malId = ids.idMal,
                aniId = ids.id,
                title = data.getTitle(),
                jpTitle = jpTitle,
                year = data.startDate.year,
                season = 1,
                episode = i,
                isAnime = true,
            ).toStringData()

            return newEpisode(linkData) {
                this.season = 1
                this.episode = i
                this.name = resolveTitle(epData)
                this.posterUrl = epData?.image ?: animeMetaData?.images?.firstOrNull()?.url ?: ""
                this.description = epData?.overview ?: "No summary available"
                this.score = Score.from10(epData?.rating)
                this.runTime = epData?.runtime
                this.addDate(epData?.airDateUtc)
            }
        }

        val episodes = (1..data.totalEpisodes()).map { createEpisode(it) }

        return if (data.format?.contains("Movie",ignoreCase = true) == true) {
            newMovieLoadResponse(data.getTitle(), url, TvType.AnimeMovie, href) {
                addAniListId(id.toInt())
                addMalId(ids.idMal)
                this.year = data.startDate.year
                this.plot = data.description
                this.backgroundPosterUrl = backgroundUrl ?: animeMetaData?.images?.firstOrNull { it.coverType == "Fanart" }?.url ?: data.bannerImage
                this.posterUrl = posterurl ?: animeMetaData?.images
                    ?.firstOrNull { it.coverType.equals("Poster", ignoreCase = true) }
                    ?.url
                    ?: data.getCoverImage()
                try { this.logoUrl = logoposter } catch(_:Throwable){}
                this.tags = data.genres
            }
        } else {
            newAnimeLoadResponse(data.getTitle(), url, TvType.Anime) {
                addAniListId(id.toInt())
                addMalId(ids.idMal)
                addEpisodes(DubStatus.Subbed, episodes)
                this.year = data.startDate.year
                this.plot = data.description
                this.backgroundPosterUrl =
                    animeMetaData?.images?.firstOrNull { it.coverType == "Fanart" }?.url
                        ?: data.bannerImage
                this.posterUrl = animeMetaData?.images
                    ?.firstOrNull { it.coverType.equals("Poster", ignoreCase = true) }
                    ?.url
                    ?: data.getCoverImage()
                try { this.logoUrl = logoposter } catch(_:Throwable){}
                this.tags = data.genres
                this.showStatus = getStatus(data.status)
                this.recommendations = data.recommendations?.edges
                    ?.mapNotNull { edge ->
                        val recommendation = edge.node.mediaRecommendation ?:return@mapNotNull null
                        val title = recommendation.title?.english
                            ?: recommendation.title?.romaji
                            ?:  "Unknown"
                        val recommendationUrl = "$mainUrl/anime/${recommendation.id}"
                        newAnimeSearchResponse(title, recommendationUrl, TvType.Anime).apply {
                            this.posterUrl = recommendation.coverImage?.large
                        }
                    }
            }
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {

        val provider = sharedPref.getString("debrid_provider", null)
        val key = sharedPref.getString("debrid_key", null)
        val mediaData = tryParseJson<LinkData>(data) ?: throw ErrorLoadingException("Gagal memuat data video")
        var episode = mediaData.episode
        val aniid = mediaData.aniId
        var kitsuId = -1
        var type = TvType.TvSeries
        var anidbEid: Int? = null

        try {
            val anijson = app.get("https://api.ani.zip/mappings?anilist_id=$aniid", timeout = 10_000L).text
            val aniData = tryParseJson<AniZipData>(anijson)
            val mappings = aniData?.mappings
            if (mappings != null) {
                kitsuId = mappings.kitsuId ?: -1
                val rawtype = mappings.type ?: ""
                if (rawtype.contains("MOVIE", ignoreCase = true)) {
                    type = TvType.Movie
                    episode = 1
                }
            }
            anidbEid = try { getAnidbEid(anijson, episode) } catch (_: Exception) { null }

        } catch (e: Exception) {
            logError(e)
        }

        val debianapiUrl = buildTorrentioApiUrl(sharedPref, torrentioDebian)
        val meteorUrl = buildMeteorUrl(sharedPref, Meteorfortheweebs)

        val filtered = filteredCallback(sharedPref, callback)

        if (!provider.isNullOrEmpty() && !key.isNullOrEmpty()) {
            if (kitsuId != -1) {
                runAllAsync(
                    { invokeTorrentioAnimeDebian(debianapiUrl, type, kitsuId, episode, callback, filtered) },
                    { invokeTorboxAnimeDebian(TorboxAPI, key, type, kitsuId, episode, callback, filtered) },
                    { invokeMeteorAnimeDebian(meteorUrl, type, kitsuId, episode, callback, filtered) }
                )
            }
        } else {
            runAllAsync(
                { invokeAnimetosho(anidbEid, callback) },
                { if (kitsuId != -1) invokeTorrentioAnimeType(torrentioDebian, type, kitsuId, episode, callback) },
                { if (kitsuId != -1)  invokeTorrentsDBAnime(TorrentsDB, kitsuId, kitsuId, episode, callback, filtered) }
            )
        }


        return true
    }

    data class AnilistAPIResponse(
        @param:JsonProperty("data") val data: AnilistData,
    ) {
        data class AnilistData(
            @param:JsonProperty("Page") val page: AnilistPage?,
            @param:JsonProperty("Media") val media: anilistMedia?,
        ) {
            data class AnilistPage(
                @param:JsonProperty("pageInfo") val pageInfo: LikePageInfo,
                @param:JsonProperty("media") val media: List<Media>,
            )
        }

        data class anilistMedia(
            @param:JsonProperty("id") val id: Int,
            @param:JsonProperty("startDate") val startDate: StartDate,
            @param:JsonProperty("episodes") val episodes: Int?,
            @param:JsonProperty("title") val title: Title,
            @param:JsonProperty("season") val season: String?,
            @param:JsonProperty("genres") val genres: List<String>,
            @param:JsonProperty("averageScore") val averageScore: Int,
            @param:JsonProperty("status") val status: String,
            @param:JsonProperty("description") val description: String?,
            @param:JsonProperty("coverImage") val coverImage: CoverImage,
            @param:JsonProperty("bannerImage") val bannerImage: String?,
            @param:JsonProperty("nextAiringEpisode") val nextAiringEpisode: SeasonNextAiringEpisode?,
            @param:JsonProperty("airingSchedule") val airingSchedule: AiringScheduleNodes?,
            @param:JsonProperty("recommendations") val recommendations: RecommendationConnection?,
            @param:JsonProperty("format") val format: String?,
            ) {
            data class StartDate(@param:JsonProperty("year") val year: Int)

            data class AiringScheduleNodes(
                @param:JsonProperty("nodes") val nodes: List<SeasonNextAiringEpisode>?
            )

            fun totalEpisodes(): Int {
                return nextAiringEpisode?.episode?.minus(1)
                    ?: episodes ?: airingSchedule?.nodes?.getOrNull(0)?.episode
                    ?: 0
            }

            fun getTitle(): String {
                return title.english
                    ?: title.romaji ?: throw Exception("Unable to calculate total episodes")
            }

            fun getCoverImage(): String? {
                return coverImage.extraLarge ?: coverImage.large ?: coverImage.medium
            }
        }
    }

    data class LinkData(
        @param:JsonProperty("simklId") val simklId: Int? = null,
        @param:JsonProperty("traktId") val traktId: Int? = null,
        @param:JsonProperty("imdbId") val imdbId: String? = null,
        @param:JsonProperty("tmdbId") val tmdbId: Int? = null,
        @param:JsonProperty("tvdbId") val tvdbId: Int? = null,
        @param:JsonProperty("type") val type: String? = null,
        @param:JsonProperty("season") val season: Int? = null,
        @param:JsonProperty("episode") val episode: Int? = null,
        @param:JsonProperty("aniId") val aniId: Int? = null,
        @param:JsonProperty("malId") val malId: Int? = null,
        @param:JsonProperty("title") val title: String? = null,
        @param:JsonProperty("year") val year: Int? = null,
        @param:JsonProperty("orgTitle") val orgTitle: String? = null,
        @param:JsonProperty("isAnime") val isAnime: Boolean = false,
        @param:JsonProperty("airedYear") val airedYear: Int? = null,
        @param:JsonProperty("lastSeason") val lastSeason: Int? = null,
        @param:JsonProperty("epsTitle") val epsTitle: String? = null,
        @param:JsonProperty("jpTitle") val jpTitle: String? = null,
        @param:JsonProperty("date") val date: String? = null,
        @param:JsonProperty("airedDate") val airedDate: String? = null,
        @param:JsonProperty("isAsian") val isAsian: Boolean = false,
        @param:JsonProperty("isBollywood") val isBollywood: Boolean = false,
        @param:JsonProperty("isCartoon") val isCartoon: Boolean = false,
        @param:JsonProperty("isDub") val isDub: Boolean = false,
    )


    data class Media(
        @param:JsonProperty("id") val id: Int,
        @param:JsonProperty("idMal") val idMal: Int?,
        @param:JsonProperty("season") val season: String?,
        @param:JsonProperty("seasonYear") val seasonYear: Int,
        @param:JsonProperty("format") val format: String?,
        @param:JsonProperty("averageScore") val averageScore: Int,
        @param:JsonProperty("episodes") val episodes: Int,
        @param:JsonProperty("title") val title: Title,
        @param:JsonProperty("description") val description: String?,
        @param:JsonProperty("coverImage") val coverImage: CoverImage,
        @param:JsonProperty("synonyms") val synonyms: List<String>,
        @param:JsonProperty("nextAiringEpisode") val nextAiringEpisode: SeasonNextAiringEpisode?,
    )

    private suspend fun tmdbToAnimeId(title: String?, year: Int?, type: TvType): AniIds {
        if (title.isNullOrBlank()) return AniIds(null, null)

        val query = """
        query (
          ${'$'}page: Int = 1
          ${'$'}search: String
          ${'$'}sort: [MediaSort] = [POPULARITY_DESC, SCORE_DESC]
          ${'$'}type: MediaType
          ${'$'}season: MediaSeason
          ${'$'}seasonYear: Int
          ${'$'}format: [MediaFormat]
        ) {
          Page(page: ${'$'}page, perPage: 20) {
            media(
              search: ${'$'}search
              sort: ${'$'}sort
              type: ${'$'}type
              season: ${'$'}season
              seasonYear: ${'$'}seasonYear
              format_in: ${'$'}format
            ) {
              id
              idMal
            }
          }
        }
    """.trimIndent()

        val variables = mutableMapOf(
            "search" to title,
            "sort" to listOf("SEARCH_MATCH"),
            "type" to "ANIME",
            "format" to listOf(
                if (type == TvType.AnimeMovie) "MOVIE" else "TV",
                "ONA",
                "OVA"
            )
        )

        val data = mapOf(
            "query" to query,
            "variables" to variables
        ).toJson().toRequestBody(RequestBodyTypes.JSON.toMediaTypeOrNull())

        val res = app.post(anilistAPI, requestBody = data, timeout = 15_000L).text
            .let { tryParseJson<AniSearch>(it) }
            ?.data
            ?.let { it.Page?.media ?: it.media }
            ?.firstOrNull()

        return AniIds(res?.id, res?.idMal)
    }

    data class AniIds(val id: Int? = null, val idMal: Int? = null)

    data class AniMedia(
        @param:JsonProperty("id") val id: Int? = null,
        @param:JsonProperty("idMal") val idMal: Int? = null
    )

    data class AniPage(
        @param:JsonProperty("media") val media: ArrayList<AniMedia> = arrayListOf()
    )

    data class AniData(
        @param:JsonProperty("Page") val Page: AniPage? = null,
        @param:JsonProperty("media") val media: ArrayList<AniMedia>? = null
    )

    data class AniSearch(
        @param:JsonProperty("data") val data: AniData? = null
    )

    fun getStatus(t: String?): ShowStatus {
        return when {
            t?.contains("Returning", ignoreCase = true) == true -> ShowStatus.Ongoing
            t?.contains("RELEASING", ignoreCase = true) == true -> ShowStatus.Ongoing
            else -> ShowStatus.Completed
        }
    }
}
